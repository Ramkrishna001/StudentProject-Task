package com.student.dao.impl;

import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.student.dao.StudentDao;
import com.student.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Long saveStudent(Student student) {

		return (Long) sessionFactory.getCurrentSession().save(student);
	}

	@Override
	public List<Student> getAllStudent() {
		 TypedQuery<Student> query = sessionFactory.getCurrentSession().createQuery("FROM Student s", Student.class);
	     List<Student> results = query.getResultList();
		return results;
	}

	@Override
	public Boolean login(String emailId, String password) {

		@SuppressWarnings("unchecked")
		TypedQuery<Student> query = sessionFactory.getCurrentSession().createQuery("FROM Student s WHERE s.emailId = :emailId AND s.password = :password");
		query.setParameter("emailId", emailId);
		query.setParameter("password", password);
		
		if(!query.getResultList().isEmpty())
		{
			return true;
		}
		
		return false;
	}

}
