package com.student.dao;

import java.util.List;

import com.student.model.Student;

public interface StudentDao {

	public Long saveStudent(Student student);

	public List<Student> getAllStudent();

	public Boolean login(String emailId, String password);
}
