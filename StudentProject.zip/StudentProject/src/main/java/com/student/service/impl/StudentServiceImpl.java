package com.student.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.student.dao.StudentDao;
import com.student.model.Student;
import com.student.service.StudentService;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;

	@Override
	public Long saveStudent(Student student) {

		return studentDao.saveStudent(student);
	}

	@Override
	public List<Student> getAllStudent() {

		return studentDao.getAllStudent();
	}

	@Override
	public Boolean login(String emailId, String password) {

		return studentDao.login(emailId, password);
	}

}
