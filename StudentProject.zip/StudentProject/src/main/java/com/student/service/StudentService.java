package com.student.service;

import java.util.List;

import com.student.model.Student;

public interface StudentService {
	
	public Long saveStudent(Student student);

	public List<Student> getAllStudent();

	public Boolean login(String emailId, String password);
}
