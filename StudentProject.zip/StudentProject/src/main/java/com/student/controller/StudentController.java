package com.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.model.Student;
import com.student.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService studentService;

	@PostMapping("/student/create")
	public ResponseEntity<?> saveStudent(@RequestBody @Valid Student student) {
		
		Long stdId = studentService.saveStudent(student);
		student.setId(stdId);
		
		return ResponseEntity.ok().body(student);
	}

	@GetMapping("/students")
	public ResponseEntity<List<Student>> getAllStudent() {
		
		List<Student> list = studentService.getAllStudent();
		
		return ResponseEntity.ok().body(list);
	}

	@PostMapping("/login")
	public String login(@RequestBody Student student)
	{
		Boolean value = studentService.login(student.getEmailId(), student.getPassword());

		if(value)
		  return "Login Success!";	
		
		return "Login Fail!";
	}
}
